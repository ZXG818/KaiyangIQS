/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | www.openfoam.com
     \\/     M anipulation  |
-------------------------------------------------------------------------------
    Copyright (C) 2011-2017 OpenFOAM Foundation
    Copyright (C) 2019 OpenCFD Ltd.
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    shapeDiffusionFoam, which is modified by laplacianFoam and sp3Foam

Author
    Xingguang Zhou, Xi'an Jiaotong University, Nuclear Thermal-hydraulics Lab. All rights reserved. 

Group
    shapeDiffusion class

Description
    shape diffusion equation class, initialized calculation for neutron value
\*---------------------------------------------------------------------------*/


#include "zeroGradientFvPatchFields.H"

// constructors

Foam::shapeDiffusion::shapeDiffusion
(
    fvMesh& mesh
)
:
    
    IOdictionary
    (
    	IOobject
    	(
    	    "neutronicsProperties",
    	    mesh.time().constant(),
    	    mesh,
    	    IOobject::MUST_READ,
    	    IOobject::NO_WRITE
    	)
    ),

    mesh_(mesh),

    dict_
    (
        IOobject
        (
            "shapeDiffusionDictionary",
            mesh_.time().constant(),
            mesh_,
            IOobject::MUST_READ,
            IOobject::NO_WRITE
        )
    ),

    // initialization of number of groups
    nGroups_(dict_.getLabel("numberOfGroups")),

    //- Initialization of number of groups of DNP
    nDNPs_(dict_.getLabel("numberOfDNPs")), 

    // initialization of number of cell zones
    nCellZones_(dict_.getLabel("numberOfCellZones")),

    // initialization of shape flux
    shapeFlux_(nGroups_),

    //- Acutal scalar flux
    actualFlux_(nGroups_),

    //- Initialization of shape DNP
    shapeDNP_(nDNPs_),

    //- Adjoint flux, calculated by adjointFluxFoam
    adjointFlux_(nGroups_),

    //- Total beta
    betaTot_(dict_.getScalar("TotalBeta")), 

    //- Initialization state keff_0
    initKeff_(dict_.getScalar("initKeff")),

    // scatter source initialization
    scatterSource_(nGroups_),
    
    // fission source initialization
    fissionSource_(nGroups_),

    //- DNP fission source summation
    DNPFissionSource_
    (
        IOobject
        (
            "DNPFissionSource",
            mesh.time().timeName(),
            mesh,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        mesh,
        dimensionedScalar("", dimless/ dimVol / dimTime, 0.0),
        "zeroGradient"
    ),

    noNegativeConstraint_
    (
        IOobject
        (
            "noNegativeConstraint",
            mesh.time().timeName(),
            mesh,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        mesh,
        dimensionedScalar("", dimless / dimArea / dimTime, 0.0),
        "zeroGradient"
    ),

    // post process used, calculate the fission power 
    SigmaF_(nGroups_),

    //- Ask user whether to input the Diffusion group constant by hand.
    whetherDiffusionInput_(dict_.getBool("whetherDiffusionInput")),

    // initialization of diffusion group constants
    D_(nGroups_),

    // initialization of removal group constants
    SigmaR_(nGroups_),

    // initialization of total group constants
    SigmaT_(nGroups_), 

    // initialization fission energy spectrum 
    Chi_(nGroups_),
    
    // initialization nuSigmaF
    nuSigmaF_(nGroups_),

    oldnuSigmaF_(nGroups_),

    // initialization scattering matrix 
    SigmaS_(nGroups_),        // rows(groupFrom) = nGroups_

    //- 
    betaI_(nDNPs_),

    //- 
    decayI_(nDNPs_),

    //- 
    neutronVelocity_(nGroups_),

    //- Neutron density, unit: dimless, the value comes from the amplitude function (point kinetics)
    neutronDensity_
    (
        IOobject
        (
            "neutronDensity",
            mesh.time().timeName(),
            mesh,
            IOobject::NO_READ,
            IOobject::AUTO_WRITE
        ),
        mesh,
        dimensionedScalar("", dimless, 1.0),
        "zeroGradient"
    ),

    //- Neutron density derivative of time.
    neutronDensityDerivative_
    (
        IOobject
        (
            "neutronDensityDerivative",
            mesh.time().timeName(),
            mesh,
            IOobject::NO_READ,
            IOobject::AUTO_WRITE
        ),
        mesh,
        dimensionedScalar("", dimless/dimTime, 0.0),
        "zeroGradient"
    ),

    //- Kinetic parameters initialization
    F_
    (
        IOobject
        (
            "F",
            mesh.time().timeName(),
            mesh,
            IOobject::NO_READ,
            IOobject::AUTO_WRITE
        ),
        mesh,
        dimensionedScalar("", dimless/dimVol/dimTime, 1.0),
        "zeroGradient"
    ),
    FT_(1.0),
    Lambda_(1.0),
    reactivity_(0.0),
    pkDNP_(nDNPs_, 0.0),
    pkBetaI_(nDNPs_, 0.0),
    pkBetaTotal_(0.0),
    pkSolver_(dict_.lookupOrDefault<word>("pkSolver", "Rosenbrock34"))
{
    // create PtrList of shape flux, allocate the memory
    forAll(shapeFlux_, groupI)
    {
        shapeFlux_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "shapeFlux_"+Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::MUST_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_
            )
        );
    }

    //- Actual scalar flux
    forAll (actualFlux_, groupI)
    {
        actualFlux_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "actualFlux_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless/dimArea/dimTime, SMALL),
                "zeroGradient"
            )
        );
    }

    forAll (shapeDNP_, familyI)
    {
        shapeDNP_.set
        (
            familyI,
            new volScalarField
            (
                IOobject
                (
                    "shapeDNP_"+Foam::name(familyI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::MUST_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_
            )
        );
    }

    forAll (adjointFlux_, groupI)
    {
        adjointFlux_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "adjointFlux_"+Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::MUST_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_
            )
        );
    }
    
    // create PtrList of diffusion group constants, allocate the memory 
    forAll (D_, groupI)
    {
        D_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "D_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimLength, SMALL),
                "zeroGradient"
            )
        );
    }

    // create PtrList of removal group constants
    forAll (SigmaR_, groupI)
    {
        SigmaR_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "SigmaR_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless/dimLength, SMALL),
                "zeroGradient"
            )
        );
    }

    // create PtrList of total group constants
    forAll (SigmaT_, groupI)
    {
        SigmaT_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "SigmaT_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless/dimLength, SMALL),
                "zeroGradient"
            )
        );
    }

    // create PtrList of energy spectrum 
    forAll (Chi_, groupI)
    {
        Chi_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "Chi_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless, SMALL),
                "zeroGradient"
            )
        );
    }

    // create PtrList of nuSigmaF_
    forAll (nuSigmaF_, groupI)
    {
        nuSigmaF_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "nuSigmaF_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless/dimLength, SMALL),
                "zeroGradient"
            )
        );
    }

    //-
    forAll (oldnuSigmaF_, groupI)
    {
        oldnuSigmaF_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "oldnuSigmaF_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless/dimLength, SMALL),
                "zeroGradient"
            )
        );
    }
    
    // create the List<PtrList<volScalarField>> of SigmaS
    
    forAll (SigmaS_, groupFrom)
    {

        // set the cols size 
        SigmaS_[groupFrom].resize(nGroups_);

        forAll (SigmaS_[groupFrom], groupTo)
        {
            SigmaS_[groupFrom].set
            (
                groupTo,
                new volScalarField
                (
                    IOobject
                    (
                        "SigmaS" + Foam::name(groupFrom) + "_" + Foam::name(groupTo),
                        mesh_.time().timeName(),
                        mesh_,
                        IOobject::NO_READ,
                        IOobject::AUTO_WRITE
                    ),
                    mesh_,
                    dimensionedScalar("", dimless/dimLength, 1.0),
                    "zeroGradient"
                )
            );
        }
    }

    // create the PtrList of scatterSource_
    forAll (scatterSource_, groupI)
    {
        scatterSource_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "scatterSource_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless / dimVol / dimTime, 1.0),
                "zeroGradient"
            )
        );
    }

    // create the PtrList of fissionSource_
    forAll (fissionSource_, groupI)
    {
        fissionSource_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "fissionSource_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless / dimVol / dimTime, 1.0),
                "zeroGradient"
            )
        );
    }

    //- Create the PtrList of SigmaF_
    //- Post process used, to calculate the fission power 
    forAll (SigmaF_, groupI)
    {
        SigmaF_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "SigmaF_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless / dimLength, 0.0),
                "zeroGradient"
            )
        );
    }

    //- 
    forAll (betaI_, familyI)
    {
        betaI_.set
        (
            familyI,
            new volScalarField
            (
                IOobject
                (
                    "betaI_" + Foam::name(familyI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless, 0.0),
                "zeroGradient"
            )
        );
    }

    //- unit : s^-1
    forAll (decayI_, familyI)
    {
        decayI_.set
        (
            familyI,
            new volScalarField
            (
                IOobject
                (
                    "decayI_" + Foam::name(familyI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimless/dimTime, 0.0),
                "zeroGradient"
            )
        );
    }

    //- unit : m/s
    forAll (neutronVelocity_, groupI)
    {
        neutronVelocity_.set
        (
            groupI,
            new volScalarField
            (
                IOobject
                (
                    "neutronVelocity_" + Foam::name(groupI),
                    mesh_.time().timeName(),
                    mesh_,
                    IOobject::NO_READ,
                    IOobject::AUTO_WRITE
                ),
                mesh_,
                dimensionedScalar("", dimLength/dimTime, 1.0),
                "zeroGradient"
            )
        );
    }
    
    
}


// destructor

Foam::shapeDiffusion::~shapeDiffusion()
{
    
}

// member functions

PtrList<volScalarField> Foam::shapeDiffusion::shapeFlux()
{
    return shapeFlux_;
}

//- Access function
void Foam::shapeDiffusion::setNeutronDensity(scalar n)
{
    forAll (neutronDensity_, cellI)
    {
        neutronDensity_[cellI] = n;
    }
}

void Foam::shapeDiffusion::setNeutronDensityDerivative(scalar dndt)
{
    forAll (neutronDensityDerivative_, cellI)
    {
        neutronDensityDerivative_[cellI] = dndt;
    }
}

scalar Foam::shapeDiffusion::Lambda()
{
    return Lambda_;
}

scalar Foam::shapeDiffusion::reactivity()
{
    return reactivity_;
}

List<scalar> Foam::shapeDiffusion::pkDNP()
{
    return pkDNP_;
}

List<scalar> Foam::shapeDiffusion::pkBetaI()
{
    return pkBetaI_;
}

scalar Foam::shapeDiffusion::pkBetaTotal()
{
    return pkBetaTotal_;
}

label Foam::shapeDiffusion::nDNPs()
{
    return nDNPs_;
}

List<scalar> Foam::shapeDiffusion::decayI()
{
    List<scalar> tmpDecayI(nDNPs_, 0.0);
    forAll (decayI_, family)
    {
        tmpDecayI[family] = decayI_[family][0];
    }
    return tmpDecayI;
}

word Foam::shapeDiffusion::pkSolver()
{
    return pkSolver_;
}



#include "fluxEqn.H"

#include "readGroupConstants.H"

#include "readKineticConstants.H"

#include "KineticEffectiveCalc.H"

#include "ChangeGroupConstant.H"



