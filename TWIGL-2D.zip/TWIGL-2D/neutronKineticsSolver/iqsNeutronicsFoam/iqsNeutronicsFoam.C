/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | www.openfoam.com
     \\/     M anipulation  |
-------------------------------------------------------------------------------
    Copyright (C) 2011-2017 OpenFOAM Foundation
    Copyright (C) 2019 OpenCFD Ltd.
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    Quasi-static neutronics kinetic solver.

Author
    Xingguang Zhou, Xi'an Jiaotong University, Nuclear Thermal-hydraulics Lab. All rights reserved. 
    <zxg818@stu.xjtu.edu.cn, starlight_chou@163.com>

Description
    A quasi-static neutronics kinetic solver, with shape diffusion equation and point-kinetics amplitude equation.
    To accelerate the speed of neutron kinetics solving process.
\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
#include "fvOptions.H"
#include "simpleControl.H"

#include "shapeDiffusion/shapeDiffusion.H"

#include "pointKinetics/pointKinetics.H"




// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    argList::addNote
    (
        "shapeDiffusion solver for neutron transport equation."
    );

    #include "postProcess.H"

    #include "addCheckCaseOptions.H"
    #include "setRootCaseLists.H"
    #include "createTime.H"
    #include "createMesh.H"


    // initialize the control flow of simple algorithm
    simpleControl simple(mesh);

    // initialize shapeDiffusion solver
    shapeDiffusion shapeDiffusionSolver(mesh);

    //- Read the group constants
    shapeDiffusionSolver.getGroupConstants();

    //- Read the kinetic parameters.
    shapeDiffusionSolver.getKineticConstants();

    //- Initialize the amplitude PK solver
    #include "InitializeAmplitudeSolver.H"

    label flag = 0;
    scalar n0 = 1.0;

    //- Transient marching.
    Info<< "\nSolving quasi-static neutron kinetics equation\n" << endl;

    while (simple.loop())
    {
        Info<< "Time = " << runTime.timeName() << nl << endl;

        //- TWIGL case 2, change group constant for region 1.
        shapeDiffusionSolver.TWIGLChangeGroupConstant();

        // update fission source and scattering source
        shapeDiffusionSolver.updateSource();

        // solve the shapeDiffusion equations
        while (simple.correctNonOrthogonal()) // non-orthogonal correction.
        {
            shapeDiffusionSolver.solveEqn();
        }

        //- Calculate the PK parameters by shape function and adjoint flux.
        shapeDiffusionSolver.CalcKineticEffective();

        //- Solve the amplitude function with PK, little time-step
        #include "CalcAmplitudeEqn.H"

        //- Set the neutron density and its derivative to shape function.
        shapeDiffusionSolver.setNeutronDensity(yStart[0]);
        shapeDiffusionSolver.setNeutronDensityDerivative(dyStart[0]);

        // print the execution time and information.
        runTime.printExecutionTime(Info);

        // write the files
        runTime.write();
    }

    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //


