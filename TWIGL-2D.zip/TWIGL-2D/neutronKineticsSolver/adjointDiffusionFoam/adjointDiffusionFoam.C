/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | www.openfoam.com
     \\/     M anipulation  |
-------------------------------------------------------------------------------
    Copyright (C) 2011-2017 OpenFOAM Foundation
    Copyright (C) 2019 OpenCFD Ltd.
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    adjointDiffusionFoam, which is modified by laplacianFoam

Author
    Xingguang Zhou, Xi'an Jiaotong University, Nuclear Thermal-hydraulics Lab. All rights reserved. 

Group
    Simplified low-order neutron transport solver. 

Description
    adjointDiffusion solver for neutron tranport equation.
\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
#include "fvOptions.H"
#include "simpleControl.H"

#include "adjointDiffusion.H"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    argList::addNote
    (
        "adjointDiffusion solver for neutron transport equation."
    );

    #include "postProcess.H"

    #include "addCheckCaseOptions.H"
    #include "setRootCaseLists.H"
    #include "createTime.H"
    #include "createMesh.H"


    // initialize the control flow of simple algorithm

    simpleControl simple(mesh);

    // initialize adjointDiffusion solver

    adjointDiffusion adjointDiffusionSolver(mesh);

    // read the group constants
    
    adjointDiffusionSolver.getGroupConstants();

    // power iteration

    Info<< "\nSolving adjointDiffusion equation\n" << endl;

    while (simple.loop())
    {
        Info<< "Time = " << runTime.timeName() << nl << endl;

        // calculate last total fission source, used before Foam::adjointDiffusion::solveEqn()

        adjointDiffusionSolver.calcLastTotalFissionSource();

        // update fission source and scattering source

        adjointDiffusionSolver.updateSource();

        // solve the adjointDiffusion equations

        while (simple.correctNonOrthogonal()) // non-orthogonal correction.
        {
            adjointDiffusionSolver.solveEqn();
        }

        // normalized flux0 and flux2

        // adjointDiffusionSolver.normalizedFlux();

        // calculate current total fission source, used after Foam::adjointDiffusion::solveEqn()

        adjointDiffusionSolver.calcCurrentTotalFissionSource();

        // calculate the k-eigenvalue

        adjointDiffusionSolver.calcKeff();

        // print the execution time and information.

        runTime.printExecutionTime(Info);

        // print the keff and its residual

        Info << "[ * ] keff = " << adjointDiffusionSolver.keff() << ", residual keff = " << adjointDiffusionSolver.residualKeff() << endl << endl;

        // judge the residual of keff
        if (adjointDiffusionSolver.residualKeff() < adjointDiffusionSolver.keffConvergenceCriterion() && 
            adjointDiffusionSolver.maxFluxResidual() < 1e-4)
        {
            Info << "The residual of k-eigenvalue is lower than " << adjointDiffusionSolver.keffConvergenceCriterion() << " ." << endl;

            Info << "Power iteration is converged, done." << endl;

            runTime.write();

            //- End the power iteration.
            break;
        }

        // write the files
        runTime.write();
    }

    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //
